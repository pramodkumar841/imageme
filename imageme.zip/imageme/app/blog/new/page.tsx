import type { Metadata } from "next";
import { redirect } from "next/navigation";
import BlogEditor from "@/components/blog/BlogEditor";
import { isAuthenticated } from "@/lib/auth";

export const metadata: Metadata = {
    title: "Write a Blog Post",
    description: "Create and publish a new blog post on PDFTools.",
    robots: { index: false, follow: false },
};

export default async function NewBlogPage() {
    if (!(await isAuthenticated())) {
        redirect("/login");
    }

    return (
        <div className="content-container py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-10">
                <h1 className="section-title mb-4">Write a Blog Post</h1>
                <p className="section-subtitle mx-auto">
                    Share your knowledge about PDFs, document management, and productivity tips.
                </p>
            </div>
            <BlogEditor />
        </div>
    );
}
