import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getPostBySlug, getAllSlugs } from "@/lib/blog";
import { isAuthenticated } from "@/lib/auth";
import { Calendar, Clock, ArrowLeft, Tag, User } from "lucide-react";
import BlogActions from "@/components/blog/BlogActions";

/* ── Dynamic SEO Metadata ──────────────────────────────── */
export async function generateMetadata({
    params,
}: {
    params: Promise<{ slug: string }>;
}): Promise<Metadata> {
    const { slug } = await params;
    const post = getPostBySlug(slug);

    if (!post) {
        return { title: "Post Not Found" };
    }

    return {
        title: post.title,
        description: post.excerpt,
        keywords: post.tags,
        authors: [{ name: post.author }],
        alternates: { canonical: `/blog/${post.slug}` },
        openGraph: {
            type: "article",
            title: post.title,
            description: post.excerpt,
            url: `/blog/${post.slug}`,
            publishedTime: post.publishedAt,
            modifiedTime: post.updatedAt,
            authors: [post.author],
            tags: post.tags,
            section: post.category,
        },
        twitter: {
            card: "summary_large_image",
            title: post.title,
            description: post.excerpt,
        },
    };
}

/* ── Static Params (SSG for all existing slugs) ────────── */
export async function generateStaticParams() {
    return getAllSlugs().map((slug) => ({ slug }));
}

/* ── Page Component ────────────────────────────────────── */
export default async function BlogPostPage({
    params,
}: {
    params: Promise<{ slug: string }>;
}) {
    const { slug } = await params;
    const post = getPostBySlug(slug);
    const isAdmin = await isAuthenticated();

    if (!post) {
        notFound();
    }

    return (
        <>
            {/* JSON-LD Article */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "BlogPosting",
                        headline: post.title,
                        description: post.excerpt,
                        url: `https://pdftools.com/blog/${post.slug}`,
                        datePublished: post.publishedAt,
                        dateModified: post.updatedAt,
                        author: {
                            "@type": "Person",
                            name: post.author,
                        },
                        publisher: {
                            "@type": "Organization",
                            name: "PDFTools",
                            url: "https://pdftools.com",
                        },
                        mainEntityOfPage: {
                            "@type": "WebPage",
                            "@id": `https://pdftools.com/blog/${post.slug}`,
                        },
                        keywords: post.tags.join(", "),
                        articleSection: post.category,
                        wordCount: post.content.replace(/<[^>]*>/g, "").split(/\s+/).length,
                    }),
                }}
            />

            {/* BreadcrumbList JSON-LD */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "BreadcrumbList",
                        itemListElement: [
                            { "@type": "ListItem", position: 1, name: "Home", item: "https://pdftools.com" },
                            { "@type": "ListItem", position: 2, name: "Blog", item: "https://pdftools.com/blog" },
                            { "@type": "ListItem", position: 3, name: post.title, item: `https://pdftools.com/blog/${post.slug}` },
                        ],
                    }),
                }}
            />

            <article className="content-container py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Breadcrumb Navigation */}
                <nav aria-label="Breadcrumb" className="mb-8">
                    <ol className="flex items-center gap-2 text-sm text-muted-foreground">
                        <li>
                            <Link href="/" className="hover:text-foreground transition-colors">
                                Home
                            </Link>
                        </li>
                        <li>/</li>
                        <li>
                            <Link href="/blog" className="hover:text-foreground transition-colors">
                                Blog
                            </Link>
                        </li>
                        <li>/</li>
                        <li className="text-foreground font-medium truncate max-w-[200px]">
                            {post.title}
                        </li>
                    </ol>
                </nav>

                {/* Back Link */}
                <Link
                    href="/blog"
                    className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-6"
                >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Blog
                </Link>

                {/* Article Header */}
                <header className="mb-10">
                    <div className="flex items-start justify-between mb-4">
                        {/* Category */}
                        <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-primary/10 text-primary">
                            {post.category}
                        </span>

                        {/* Admin Actions */}
                        {isAdmin && <BlogActions slug={post.slug} variant="full" />}
                    </div>

                    {/* Title */}
                    <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-6 leading-tight">
                        {post.title}
                    </h1>

                    {/* Excerpt */}
                    <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                        {post.excerpt}
                    </p>

                    {/* Meta bar */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground border-y border-border py-4">
                        <span className="flex items-center gap-1.5">
                            <User className="w-4 h-4" />
                            {post.author}
                        </span>
                        <span className="flex items-center gap-1.5">
                            <Calendar className="w-4 h-4" />
                            {new Date(post.publishedAt).toLocaleDateString("en-US", {
                                month: "long",
                                day: "numeric",
                                year: "numeric",
                            })}
                        </span>
                        <span className="flex items-center gap-1.5">
                            <Clock className="w-4 h-4" />
                            {post.readingTime} min read
                        </span>
                    </div>
                </header>

                {/* Cover Image */}
                <div className="aspect-[21/9] bg-muted relative rounded-3xl flex items-center justify-center overflow-hidden mb-12 shadow-sm">
                    {post.coverImage && post.coverImage !== "/blog/default-cover.jpg" ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={post.coverImage} alt={post.title} className="object-cover w-full h-full" />
                    ) : (
                        <span className="text-6xl font-bold text-primary/10">
                            {post.category}
                        </span>
                    )}
                </div>

                {/* Article Content */}
                <div
                    className="prose prose-lg max-w-none
            prose-headings:font-bold prose-headings:tracking-tight
            prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
            prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3
            prose-p:leading-relaxed prose-p:text-foreground/80
            prose-a:text-primary prose-a:no-underline hover:prose-a:underline
            prose-li:text-foreground/80
            prose-strong:text-foreground
            prose-ul:my-4 prose-ol:my-4
            mb-12"
                    dangerouslySetInnerHTML={{ __html: post.content }}
                />

                {/* Tags */}
                {post.tags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 mb-10 pb-10 border-b border-border">
                        <Tag className="w-4 h-4 text-muted-foreground" />
                        {post.tags.map((tag) => (
                            <span
                                key={tag}
                                className="px-3 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground"
                            >
                                {tag}
                            </span>
                        ))}
                    </div>
                )}

                {/* CTA */}
                <div className="rounded-2xl bg-gradient-to-r from-primary/5 to-primary/10 p-8 text-center">
                    <h2 className="text-2xl font-bold mb-3">Ready to try our tools?</h2>
                    <p className="text-muted-foreground mb-6">
                        All our PDF and image tools are free, private, and work right in your browser.
                    </p>
                    <Link
                        href="/"
                        className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white bg-gradient-hero hover:opacity-90 transition-all"
                    >
                        Explore All Tools <ArrowLeft className="w-4 h-4 rotate-180" />
                    </Link>
                </div>
            </article>
        </>
    );
}
