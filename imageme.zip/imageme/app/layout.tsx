import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "@/index.css";
import { RootLayoutClient } from "./layout-client";

/* ── next/font: zero-CLS font loading ──────────────────── */
const inter = Inter({
    subsets: ["latin"],
    weight: ["300", "400", "500", "600", "700", "800"],
    display: "swap",
    variable: "--font-inter",
    preload: true,
});

/* ── Global SEO Metadata ───────────────────────────────── */
export const metadata: Metadata = {
    metadataBase: new URL("https://pdftools.com"),
    title: {
        default: "PDFTools — Free Online PDF & Image Tools | Merge, Split, Compress & Convert",
        template: "%s | PDFTools",
    },
    description:
        "Free online tools to merge, split, compress, convert, rotate, watermark, and edit PDF files — plus image compression and format conversion. No sign-up required. 100% private, processed in your browser.",
    keywords: [
        "PDF tools",
        "merge PDF",
        "split PDF",
        "compress PDF",
        "convert PDF",
        "image to PDF",
        "PDF to image",
        "rotate PDF",
        "watermark PDF",
        "page numbers PDF",
        "delete PDF pages",
        "compress image",
        "convert image",
        "free online PDF tools",
        "browser PDF editor",
    ],
    authors: [{ name: "PDFTools" }],
    creator: "PDFTools",
    publisher: "PDFTools",
    robots: {
        index: true,
        follow: true,
        "max-snippet": -1,
        "max-image-preview": "large",
        "max-video-preview": -1,
    },
    openGraph: {
        type: "website",
        locale: "en_US",
        url: "https://pdftools.com",
        siteName: "PDFTools",
        title: "PDFTools — Free Online PDF & Image Tools",
        description:
            "Free online tools to merge, split, compress, convert, rotate, and edit PDF files — plus image compression and format conversion. No sign-up required.",
    },
    twitter: {
        card: "summary_large_image",
        title: "PDFTools — Free Online PDF & Image Tools",
        description:
            "Free online PDF and image tools — merge, split, compress, convert, watermark, rotate and more. No sign-up required.",
    },
    other: {
        language: "en",
        "revisit-after": "7 days",
        rating: "general",
    },
};

export const viewport: Viewport = {
    width: "device-width",
    initialScale: 1,
    themeColor: "#ef4444",
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" className={inter.variable} suppressHydrationWarning>
            <body className="bg-background text-foreground font-sans antialiased">
                <RootLayoutClient>{children}</RootLayoutClient>
                {/* admin123 */}
            </body>
        </html>
    );
}
