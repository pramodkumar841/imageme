import type { NextConfig } from "next";

const nextConfig: NextConfig = {
    /* ── Performance optimizations ─────────────────────────── */
    reactStrictMode: true,
    compress: true,

    images: {
        formats: ["image/avif", "image/webp"],
    },

    turbopack: {
        resolveAlias: {
            // pdfjs-dist tries to require('canvas') on Node — stub it out
            canvas: { browser: "./src/lib/empty-module.js" },
        },
    },

    experimental: {
        optimizePackageImports: [
            "lucide-react",
            "framer-motion",
            "@radix-ui/react-radio-group",
            "@radix-ui/react-select",
            "@radix-ui/react-slider",
            "@radix-ui/react-tooltip",
            "@radix-ui/react-toast",
            "@radix-ui/react-label",
        ],
    },
};

export default nextConfig;
