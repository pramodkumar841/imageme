"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { PenSquare, Loader2, Eye, Edit3, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface BlogEditorProps {
    initialData?: {
        slug: string;
        title: string;
        excerpt: string;
        content: string;
        author: string;
        category: string;
        tags: string;
        coverImage: string;
    };
}

export default function BlogEditor({ initialData }: BlogEditorProps = {}) {
    const router = useRouter();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [preview, setPreview] = useState(false);
    const [error, setError] = useState("");
    const [form, setForm] = useState(
        initialData || {
            title: "",
            excerpt: "",
            content: "",
            author: "PDFTools Team",
            category: "General",
            tags: "",
            coverImage: "",
        }
    );

    const updateField = (field: string, value: string) => {
        setForm((prev) => ({ ...prev, [field]: value }));
        setError("");
    };

    const handleSubmit = async () => {
        if (!form.title.trim()) return setError("Title is required.");
        if (!form.excerpt.trim()) return setError("Excerpt is required (used for SEO meta description).");
        if (!form.content.trim()) return setError("Content is required.");
        if (form.excerpt.length > 160) return setError("Excerpt should be ≤ 160 characters for SEO.");

        setIsSubmitting(true);
        setError("");

        try {
            const isEditing = !!initialData;
            const url = isEditing ? `/api/blog/${initialData.slug}` : "/api/blog";
            const method = isEditing ? "PUT" : "POST";

            const res = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    ...form,
                    tags: form.tags
                        .split(",")
                        .map((t) => t.trim())
                        .filter(Boolean),
                }),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to create post.");
            }

            const data = await res.json();
            router.push(`/blog/${data.post.slug}`);
            router.refresh();
        } catch (err: any) {
            setError(err.message || "Something went wrong.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        try {
            const formData = new FormData();
            formData.append("file", file);

            const res = await fetch("/api/upload", {
                method: "POST",
                body: formData,
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to upload image.");
            }

            const data = await res.json();
            updateField("coverImage", data.url);
        } catch (err: any) {
            setError(err.message || "Something went wrong uploading the image.");
        }
    };

    const categories = [
        "General",
        "Guides",
        "Tips & Tricks",
        "Tutorials",
        "News",
        "Product Updates",
    ];

    return (
        <div className="space-y-8">
            {/* Title */}
            <div className="space-y-2">
                <Label htmlFor="title" className="text-sm font-semibold">
                    Title <span className="text-destructive">*</span>
                </Label>
                <Input
                    id="title"
                    placeholder="e.g., How to Merge PDF Files Online for Free"
                    value={form.title}
                    onChange={(e) => updateField("title", e.target.value)}
                    className="text-lg py-3"
                />
                <p className="text-xs text-muted-foreground">
                    Use a descriptive, keyword-rich title for better SEO ranking.
                </p>
            </div>

            {/* Excerpt / Meta Description */}
            <div className="space-y-2">
                <Label htmlFor="excerpt" className="text-sm font-semibold">
                    Excerpt / Meta Description <span className="text-destructive">*</span>
                </Label>
                <Textarea
                    id="excerpt"
                    placeholder="A compelling 1-2 sentence summary (used as meta description for search engines)"
                    value={form.excerpt}
                    onChange={(e) => updateField("excerpt", e.target.value)}
                    rows={2}
                />
                <p className="text-xs text-muted-foreground">
                    {form.excerpt.length}/160 characters — Keep under 160 for optimal SEO display.
                    <span className={form.excerpt.length > 160 ? " text-destructive font-semibold" : ""}>
                        {form.excerpt.length > 160 && " ⚠ Too long!"}
                    </span>
                </p>
            </div>

            {/* Cover Image Upload */}
            <div className="space-y-2">
                <Label htmlFor="coverImage" className="text-sm font-semibold">
                    Cover Image
                </Label>
                <div className="flex items-center gap-4">
                    {form.coverImage && (
                        <div className="relative w-32 h-20 overflow-hidden rounded-lg border border-border">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={form.coverImage} alt="Cover preview" className="object-cover w-full h-full" />
                        </div>
                    )}
                    <div className="flex-1">
                        <Input
                            id="coverImage"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="cursor-pointer file:cursor-pointer file:font-semibold text-sm file:text-primary file:bg-primary/10 file:border-0 hover:file:bg-primary/20"
                        />
                        <p className="text-xs text-muted-foreground mt-2">
                            Select a high-quality image (e.g., JPEG, PNG, or WebP). Max 5MB recommended.
                        </p>
                    </div>
                </div>
            </div>

            {/* Two-column: Author + Category */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                    <Label htmlFor="author" className="text-sm font-semibold">
                        Author
                    </Label>
                    <Input
                        id="author"
                        placeholder="Author name"
                        value={form.author}
                        onChange={(e) => updateField("author", e.target.value)}
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="category" className="text-sm font-semibold">
                        Category
                    </Label>
                    <select
                        id="category"
                        value={form.category}
                        onChange={(e) => updateField("category", e.target.value)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                        {categories.map((c) => (
                            <option key={c} value={c}>
                                {c}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Tags */}
            <div className="space-y-2">
                <Label htmlFor="tags" className="text-sm font-semibold">
                    Tags
                </Label>
                <Input
                    id="tags"
                    placeholder="e.g., merge pdf, tutorial, tips (comma separated)"
                    value={form.tags}
                    onChange={(e) => updateField("tags", e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                    Comma-separated keywords. Used for SEO keywords meta tag.
                </p>
            </div>

            {/* Content */}
            <div className="space-y-2">
                <div className="flex items-center justify-between">
                    <Label htmlFor="content" className="text-sm font-semibold">
                        Content (HTML) <span className="text-destructive">*</span>
                    </Label>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setPreview(!preview)}
                        className="text-xs"
                    >
                        {preview ? (
                            <><Edit3 className="w-3.5 h-3.5 mr-1" /> Edit</>
                        ) : (
                            <><Eye className="w-3.5 h-3.5 mr-1" /> Preview</>
                        )}
                    </Button>
                </div>

                {preview ? (
                    <div
                        className="min-h-[300px] rounded-md border border-input bg-background p-4 prose prose-sm max-w-none
              prose-headings:font-bold prose-h2:text-xl prose-h3:text-lg
              prose-p:leading-relaxed prose-a:text-primary"
                        dangerouslySetInnerHTML={{ __html: form.content || "<p class='text-muted-foreground'>Nothing to preview yet…</p>" }}
                    />
                ) : (
                    <Textarea
                        id="content"
                        placeholder={`Write your blog post content in HTML.\n\nExample:\n<h2>Introduction</h2>\n<p>Your content here...</p>\n\n<h2>Step 1: Upload Files</h2>\n<p>Navigate to the <a href="/merge">Merge PDF tool</a>...</p>`}
                        value={form.content}
                        onChange={(e) => updateField("content", e.target.value)}
                        rows={15}
                        className="font-mono text-sm"
                    />
                )}
                <p className="text-xs text-muted-foreground">
                    Use HTML tags: {'<h2>'}, {'<h3>'}, {'<p>'}, {'<ul>'}, {'<ol>'}, {'<li>'}, {'<a href="...">'}, {'<strong>'}, {'<em>'}
                </p>
            </div>

            {/* Error message */}
            {error && (
                <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-4 text-sm text-destructive">
                    {error}
                </div>
            )}

            {/* Submit */}
            <div className="flex items-center gap-4 pt-4 border-t border-border">
                <Button
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="btn-tool"
                    size="lg"
                >
                    {isSubmitting ? (
                        <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            {initialData ? "Updating…" : "Publishing…"}
                        </>
                    ) : (
                        <>
                            {initialData ? <Save className="w-5 h-5" /> : <PenSquare className="w-5 h-5" />}
                            {initialData ? "Update Post" : "Publish Post"}
                        </>
                    )}
                </Button>
                <p className="text-xs text-muted-foreground">
                    Your post will be live immediately with full SEO metadata.
                </p>
            </div>
        </div>
    );
}
