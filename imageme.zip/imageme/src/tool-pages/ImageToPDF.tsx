"use client";

import { useState, useCallback, useEffect } from "react";
import { PDFDocument } from "pdf-lib";
import { Image, Download } from "lucide-react";
import { saveAs } from "file-saver";
import { FileDropzone } from "@/components/shared/FileDropzone";
import { ToolPageHeader } from "@/components/shared/ToolPageHeader";
import { ProcessingButton } from "@/components/shared/ProcessingButton";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function ImageToPDF() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]);
  const { toast } = useToast();

  // Revoke preview Object URLs when they are no longer needed to prevent memory leaks
  useEffect(() => {
    return () => {
      previews.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [previews]);

  const handleFilesChange = useCallback(async (newFiles: File[]) => {
    // Revoke previous previews before generating new ones
    setPreviews((prev) => {
      prev.forEach((url) => URL.revokeObjectURL(url));
      return [];
    });
    setFiles(newFiles);

    // Generate Object URL previews (faster and memory-safe via revokeObjectURL)
    const newPreviews = newFiles.map((file) => URL.createObjectURL(file));
    setPreviews(newPreviews);
  }, []);

  const convertToPDF = async () => {
    if (files.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one image.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      const pdfDoc = await PDFDocument.create();
      const skipped: string[] = [];

      for (const file of files) {
        const arrayBuffer = await file.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);

        if (file.type === "image/jpeg" || file.type === "image/jpg") {
          const image = await pdfDoc.embedJpg(uint8Array);
          const page = pdfDoc.addPage([image.width, image.height]);
          page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
        } else if (file.type === "image/png") {
          const image = await pdfDoc.embedPng(uint8Array);
          const page = pdfDoc.addPage([image.width, image.height]);
          page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
        } else {
          // Unsupported format: skip and report to user
          skipped.push(file.name);
        }
      }

      if (pdfDoc.getPageCount() === 0) {
        toast({
          title: "No supported images",
          description: "Only JPG and PNG are supported. Please convert other formats first.",
          variant: "destructive",
        });
        return;
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([new Uint8Array(pdfBytes)], { type: "application/pdf" });
      saveAs(blob, "images.pdf");

      if (skipped.length > 0) {
        toast({
          title: `Converted with warnings`,
          description: `Skipped ${skipped.length} unsupported file(s): ${skipped.join(", ")}`,
        });
      } else {
        toast({
          title: "Success!",
          description: `${files.length} image${files.length !== 1 ? "s" : ""} converted to PDF.`,
        });
      }
    } catch (error) {
      console.error("Error converting to PDF:", error);
      toast({
        title: "Error",
        description: "Failed to convert images. Please ensure they are valid JPG or PNG files.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <div className="content-container tool-page-content">
        <ToolPageHeader
          title="Image to PDF"
          description="Convert your images to a PDF document. Supports JPG and PNG formats."
          icon={Image}
          category="convert"
        />

        <div className="max-w-2xl mx-auto">
          {files.length === 0 ? (
            <FileDropzone
              files={files}
              onFilesChange={handleFilesChange}
              accept={{
                "image/jpeg": [".jpg", ".jpeg"],
                "image/png": [".png"],
              }}
              title="Drop images here"
              subtitle="JPG, PNG supported"
            />
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {previews.map((preview, index) => (
                  <div
                    key={`${files[index]?.name}-${index}`}
                    className="aspect-square rounded-xl overflow-hidden bg-muted border border-border"
                  >
                    <img
                      src={preview}
                      alt={files[index]?.name ?? `Image ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>

              <FileDropzone
                files={[]}
                onFilesChange={(newFiles) => handleFilesChange([...files, ...newFiles])}
                accept={{
                  "image/jpeg": [".jpg", ".jpeg"],
                  "image/png": [".png"],
                }}
                title="Add more images"
                subtitle="Drop here or click"
              />

              <div className="flex justify-center gap-4">
                <button
                  onClick={() => {
                    setFiles([]);
                    setPreviews((prev) => {
                      prev.forEach((url) => URL.revokeObjectURL(url));
                      return [];
                    });
                  }}
                  className="text-sm text-muted-foreground hover:text-foreground"
                >
                  Clear all
                </button>
                <ProcessingButton
                  onClick={convertToPDF}
                  isProcessing={isProcessing}
                  processingText="Converting..."
                >
                  <Download className="w-5 h-5" />
                  Convert to PDF
                </ProcessingButton>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
}
