"use client";

import { motion } from "framer-motion";
import {
  Combine,
  Split,
  Minimize2,
  Image,
  FileImage,
  FileText,
  RotateCw,
  Stamp,
  Hash,
  Trash2,
  Shield,
  Zap,
  Globe,
  RefreshCw,
  ImageDown,
  LucideIcon
} from "lucide-react";
import { ToolCard, ToolCategory } from "@/components/shared/ToolCard";

interface Tool {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  category: ToolCategory;
}

const tools: Tool[] = [
  {
    title: "Convert Image",
    description: "Convert images to WebP, PNG, or JPG format",
    icon: RefreshCw,
    href: "/convert-image",
    category: "convert",
  },
  {
    title: "Compress Image",
    description: "Reduce image file size while maintaining quality",
    icon: ImageDown,
    href: "/compress-image",
    category: "compress",
  },
  {
    title: "Merge PDF",
    description: "Combine multiple PDF files into one document",
    icon: Combine,
    href: "/merge",
    category: "merge",
  },
  {
    title: "Split PDF",
    description: "Extract pages or split a PDF into multiple files",
    icon: Split,
    href: "/split",
    category: "split",
  },
  {
    title: "Compress PDF",
    description: "Reduce PDF file size while maintaining quality",
    icon: Minimize2,
    href: "/compress",
    category: "compress",
  },
  {
    title: "Image to PDF",
    description: "Convert JPG, PNG, and other images to PDF",
    icon: Image,
    href: "/image-to-pdf",
    category: "convert",
  },
  {
    title: "PDF to Image",
    description: "Export PDF pages as JPG or PNG images",
    icon: FileImage,
    href: "/pdf-to-image",
    category: "convert",
  },
  // {
  //   title: "Word to PDF",
  //   description: "Convert DOCX documents to PDF format",
  //   icon: FileText,
  //   href: "/word-to-pdf",
  //   category: "convert",
  // },
  {
    title: "Rotate PDF",
    description: "Rotate PDF pages 90°, 180°, or 270°",
    icon: RotateCw,
    href: "/rotate",
    category: "edit",
  },
  {
    title: "Add Watermark",
    description: "Add text or image watermarks to your PDF",
    icon: Stamp,
    href: "/watermark",
    category: "edit",
  },
  {
    title: "Page Numbers",
    description: "Add page numbers to your PDF document",
    icon: Hash,
    href: "/page-numbers",
    category: "edit",
  },
  {
    title: "Delete Pages",
    description: "Remove unwanted pages from your PDF",
    icon: Trash2,
    href: "/delete-pages",
    category: "split",
  },

];

const features = [
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your files are processed locally and never stored on our servers.",
  },
  {
    icon: Zap,
    title: "Fast Processing",
    description: "Advanced algorithms ensure quick processing of your PDF files.",
  },
  {
    icon: Globe,
    title: "Works Everywhere",
    description: "Use our tools on any device with a modern web browser.",
  },
];

const Index = () => {
  return (
    <>
      {/* Hero Section */}
      {/* <section className="py-20 md:py-32">
        <div className="content-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
              Every PDF tool you need,{" "}
              <span className="text-gradient">all in one place</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Free online tools to merge, split, compress, convert, and edit PDF files.
              No registration required.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted text-sm"
          >
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-muted-foreground">No sign-up required • 100% Free</span>
          </motion.div>
        </div>
      </section> */}

      {/* Tools Grid */}
      <section className="py-16 bg-muted/30">
        <div className="content-container">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Explore Our Tools</h2>
            <p className="section-subtitle mx-auto">
              Choose from our collection of professional PDF tools
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {tools.map((tool, index) => (
              <ToolCard
                key={tool.title}
                title={tool.title}
                description={tool.description}
                icon={tool.icon}
                href={tool.href}
                category={tool.category}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="content-container">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Why choose PDFTools?</h2>
            <p className="section-subtitle mx-auto">
              Built with security and performance in mind
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="text-center p-8"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="content-container">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="rounded-3xl bg-gradient-hero p-12 md:p-20 text-center text-white"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to get started?
            </h2>
            <p className="text-lg opacity-90 mb-8 max-w-xl mx-auto">
              Choose a tool above and start editing your PDFs for free.
              No registration, no watermarks, no limits.
            </p>
            <a
              href="#tools"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-semibold text-lg bg-white text-primary hover:bg-white/90 transition-colors"
            >
              Explore All Tools
            </a>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Index;
